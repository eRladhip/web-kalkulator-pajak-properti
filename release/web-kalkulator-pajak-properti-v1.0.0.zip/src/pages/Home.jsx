import React from 'react'
import CalculatorForm from '../components/CalculatorForm'

export default function Home(){
  return (
    <div>
      <CalculatorForm />
    </div>
  )
}
